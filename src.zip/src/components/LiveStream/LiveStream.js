import React, { useEffect, useRef } from 'react';
import socketIOClient from 'socket.io-client';

const LiveStream = () => {
  const videoRef = useRef();

  useEffect(() => {
    const socket = socketIOClient('http://localhost:5000');

    console.log(socket);
    socket.on('image', (imageData) => {
      // console.log(imageData);
      // Update the video element with the received frame
      videoRef.current.src = `data:image/jpeg;base64,${imageData}`;
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  return (
    <div className="items-center justify-center rounded-2xl">
      <img ref={videoRef} style={{ borderRadius: '15px' }} height={500} width={1200} alt='video source' className='' />
    </div>
  );
};

export default LiveStream;
