import './App.css';
import { FooterLinks } from './components/Footer/Footer';
import { HeaderResponsive } from './components/Header/Header';
import LiveStream from './components/LiveStream/LiveStream';
import { CheckWithUploadOrDrag } from "./components/CheckWithUploadOrDrag/CheckWithUploadorDrag"
import { CheckWithUrl } from "./components/CheckWithUrl/CheckWithUrl"
import { Divider } from '@mantine/core';
// import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
// import AboutProject from './components/AboutProject'

const headerLinks = [{ link: '/aboutUs', label: 'AboutProject' }, { link: '/TotalDetected', label: 'TotalDetected' }, { link: 'google.com', label: 'Refrence Projects' }];

function App() {


  return (
    // <Router>
    <div className='head flex flex-col items-center'>
      <div className='mb-12'>
        <HeaderResponsive links={headerLinks} />
      </div>
      <hr className='mt-4' />
      <div className='live bg-slate-700 mt-20'>
        <LiveStream />
      </div>
      <div className=' mt-16 mb-20 flex flex-row w-6/12 justify-between'>
        <div className='flex'>
          < CheckWithUploadOrDrag />
        </div>
        <Divider my="sm" className='mr-16 ml-16' orientation='vertical' />
        <div className='flex'>
          <CheckWithUrl />
        </div>
      </div>
      <div className='text-cyan-50 w-fit' >
        <FooterLinks />
      </div>
      {/* <Switch> */}
      {/* <Route exact path='/' component={Home} /> */}
      {/* <Route path='/about' component={AboutProject} /> */}
      {/* <Route path='/about' component={About} /> */}
      {/* </Switch> */}
    </div>
    // </Router>
  );
}

export default App;
