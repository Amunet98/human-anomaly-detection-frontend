import { Divider } from "@mantine/core"

export const about = () => {
    return (
        <div>About</div>
    )
}